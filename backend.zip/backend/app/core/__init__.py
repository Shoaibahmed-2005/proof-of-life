# Core configurations module
