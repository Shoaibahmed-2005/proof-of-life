# Application package initialization
